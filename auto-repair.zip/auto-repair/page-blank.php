<?php
/**
 * Single page template
 *
 * Template Name: Blank
 *
 * @package wpv
 * @subpackage auto-repair
 */

get_template_part( 'page' );