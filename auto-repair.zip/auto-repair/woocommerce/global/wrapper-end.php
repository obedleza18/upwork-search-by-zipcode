<?php
/**
 * Content wrappers
 *
 * @author 		Vamtam
 * @package 	wpv
 * @subpackage  auto-repair
 * @version     2.1.0
 */

global $post;

?>
		</div>
	</article>
	<?php WpvTemplates::right_sidebar() ?>
</div>
