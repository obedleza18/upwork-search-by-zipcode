<div class="config-separator <?php echo esc_attr( $class ) ?>" data-tab-class="<?php if ( isset( $tab_class ) ) echo esc_attr( $tab_class ) ?>">
	<?php echo $name // xss ok ?>
</div>
